/*    */ package com.zyzhou.a;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public final class a
/*    */ {
/*    */   static
/*    */   {
/* 23 */     Logger.getLogger(a.class);
/*    */   }
/*    */ 
/*    */   public static boolean a(String s)
/*    */   {
/* 42 */     if ((s == null) || (s.trim().equals(""))) {
/* 43 */       return true;
/*    */     }
/* 45 */     return false;
/*    */   }
/*    */ }

/* Location:           H:\New\monitor\monitor.jar
 * Qualified Name:     com.zyzhou.a.a
 * JD-Core Version:    0.6.2
 */