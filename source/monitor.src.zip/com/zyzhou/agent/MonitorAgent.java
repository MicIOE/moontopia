/*    */ package com.zyzhou.agent;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MonitorAgent
/*    */ {
/*    */   static
/*    */   {
/* 34 */     Logger.getLogger(MonitorAgent.class);
/*    */   }
/*    */ 
/*    */   public static void run()
/*    */   {
/* 48 */     a.a();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 59 */     run();
/*    */   }
/*    */ }

/* Location:           H:\New\monitor\monitor.jar
 * Qualified Name:     com.zyzhou.agent.MonitorAgent
 * JD-Core Version:    0.6.2
 */